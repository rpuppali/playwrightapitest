// @ts-check
import { test, expect } from '@playwright/test'

test('restful Booker - Create new Booking - static body', async ({ request }) => {
  const jsonbody = require('../../test-data/post_req_body.json')
  const apiresponse = await request.post('https://restful-booker.herokuapp.com/booking',{
  data: jsonbody
  });
  expect(apiresponse.ok()).toBeTruthy();
  expect(apiresponse.status()).toBe(200);
  
  const JSONData =  await apiresponse.json();
  console.log(JSONData);
  expect(JSONData.booking).toHaveProperty("firstname", "Sally");
});
