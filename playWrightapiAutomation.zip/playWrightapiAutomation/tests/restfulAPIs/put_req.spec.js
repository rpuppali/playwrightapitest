// @ts-check
import { test, expect } from '@playwright/test'
import { stringFormat } from '../../utils/common';
const apibodyjson = require('../../test-data/post_req_body_dynamic.json');

test('restful Booker - Create new Booking - dynamic JSON file', async ({ request }) => {
  
  const apidynamicbodyjson= stringFormat(JSON.stringify(apibodyjson), "Virat", "Kohli" )
  const apiresponse = await request.post('https://restful-booker.herokuapp.com/booking',{
  data: JSON.parse(apidynamicbodyjson)
  });
  
  const JSONData =  await apiresponse.json();
  const bId = JSONData.bookingid;
 
  const getAPIResponse = await request.get(`https://restful-booker.herokuapp.com/booking/${bId}`)

  //generate token 
  const postreqjsonbody = require('../../test-data/put_req_body.json');
  const postreqjsonresp = await request.post(`https://restful-booker.herokuapp.com/auth`,{
    data: postreqjsonbody
  });
  const postapiresp = await postreqjsonresp.json();
  const tokenNo =  postapiresp.token;
  console.log("token no: " + tokenNo);
  //put api call
  
  const putapijson=  require('../../test-data/put_request_body.json')
  const putapiresp =  await request.put(`https://restful-booker.herokuapp.com/booking/${bId}`, {
       headers:{
        "Content-type" :"application/json",
        "Cookie" : `token=${tokenNo}`
       },
       data: putapijson
  })
   const putapirespbody = await putapiresp.json();
   expect(putapiresp.status()).toBe(200);
   expect(putapiresp.ok()).toBeTruthy();

});
