// @ts-check
import { test, expect } from '@playwright/test'
import { stringFormat } from '../../utils/common';
const apibodyjson = require('../../test-data/post_req_body_dynamic.json');

test('restful Booker - delete api request file', async ({ request }) => {
  
  const apidynamicbodyjson= stringFormat(JSON.stringify(apibodyjson), "Virat", "Kohli" )
  const apiresponse = await request.post('https://restful-booker.herokuapp.com/booking',{
  data: JSON.parse(apidynamicbodyjson)
  });
  
  const JSONData =  await apiresponse.json();
  const bId = JSONData.bookingid;
 
  const getAPIResponse = await request.get(`https://restful-booker.herokuapp.com/booking/${bId}`)

  //generate token 
  const postreqjsonbody = require('../../test-data/put_req_body.json');
  const postreqjsonresp = await request.post(`https://restful-booker.herokuapp.com/auth`,{
    data: postreqjsonbody
  });
  const postapiresp = await postreqjsonresp.json();
  const tokenNo =  postapiresp.token;
  console.log("token no: " + tokenNo);
  //put api call
  
  const patchapijson=  require('../../test-data/patch_req_body.json')
  const patchapiresp =  await request.patch(`https://restful-booker.herokuapp.com/booking/${bId}`, {
       headers:{
        "Content-type" :"application/json",
        "Cookie" : `token=${tokenNo}`
       },
       data: patchapijson
  })
   const putapirespbody = await patchapiresp.json();
   expect(patchapiresp.status()).toBe(200);
   expect(patchapiresp.ok()).toBeTruthy();

   const deleteapiresp = await request.delete(`https://restful-booker.herokuapp.com/booking/${bId}`,{
    headers:{
        "Content-type" :"application/json",
        "Cookie" : `token=${tokenNo}`
       },
   })
 
   expect(deleteapiresp.status()).toBe(201);
   expect(deleteapiresp.statusText()).toBe("Created")

     
});
