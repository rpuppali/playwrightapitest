// @ts-check
import { test, expect } from '@playwright/test'
import { stringFormat } from '../../utils/common';
const apibodyjson = require('../../test-data/post_req_body_dynamic.json');

test('restful Booker - Create new Booking - dynamic JSON file', async ({ request }) => {
  
  const apidynamicbodyjson= stringFormat(JSON.stringify(apibodyjson), "Virat", "Kohli" )
  const apiresponse = await request.post('https://restful-booker.herokuapp.com/booking',{
  data: JSON.parse(apidynamicbodyjson)
  });
 
  console.log("__________________________");
  const JSONData =  await apiresponse.json();
  const bId = await JSONData.bookingid;
  console.log(bId);
  const getAPIResponse = await request.get(`https://restful-booker.herokuapp.com/booking/`,{
  params: {
    "firstname" : "Virat",
    "lastname"  : "Kohli"
    }

  })
  console.log(getAPIResponse);


});

