// @ts-check
import { test, expect } from '@playwright/test'
import { stringFormat } from '../../utils/common';
const apibodyjson = require('../../test-data/post_req_body_dynamic.json');

test('restful Booker - Create new Booking - dynamic JSON file', async ({ request }) => {
  
  const apidynamicbodyjson= stringFormat(JSON.stringify(apibodyjson), "Virat", "Kohli" )
  const apiresponse = await request.post('https://restful-booker.herokuapp.com/booking',{
  data: JSON.parse(apidynamicbodyjson)
  });
  
  // Validate the status code 
  expect(apiresponse.status()).toBe(200);
  expect(apiresponse.ok()).toBeTruthy();

  const JSONData =  await apiresponse.json();
  expect(JSONData.booking).toHaveProperty("firstname", "Virat");
  expect(JSONData.booking).toHaveProperty("lastname", "Kohli");

});

