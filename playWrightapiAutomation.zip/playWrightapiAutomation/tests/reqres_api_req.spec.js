// @ts-check
import { test, expect } from '@playwright/test'

test('get api request - users list1', async ({ request }) => {
  const apiresponse = await request.get('https://reqres.in/api/users?page=2');
  expect(apiresponse.ok()).toBeTruthy();
  expect(apiresponse.status()).toBe(200);
   
});

test('post api request - add user', async ({ request }) => {
  const apiresponse = await request.post('https://reqres.in/api/users' , {
    data:
    {
      "name": "morpheus",
      "job": "leader"
    }
  });
  expect(apiresponse.status()).toBe(201);
  expect(apiresponse.statusText()).toBe('Created');
});

test('put api request - update user', async ({ request }) => {
  const apiresponse = await request.put('https://reqres.in/api/users/2' , {
    data:
    {
      "name": "morpheus",
      "job": "zion resident"
    }
  });
  expect(apiresponse.status()).toBe(200);
  expect(apiresponse.statusText()).toBe('OK');
});

// test('delete api request - update user', async ({ request }) => {
//   const apiresponse = await request.delete('api/users/2');
//   expect(apiresponse.status()).toBe(204);
//   expect(apiresponse.statusText()).toBe('No Content');

// });